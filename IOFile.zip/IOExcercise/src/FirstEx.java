import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class FirstEx {
	
	
	public static void countCharactersInFile(char caharacter, String file)  {
		    int count=0;
            FileWriter writer;
            BufferedReader reader;
			try {
				File MyFile= new File(file);
				    writer = new FileWriter(MyFile, true);
		            writer.write("Hello World");
		            writer.write("\r\n");   // write new line
		            writer.write("Good Bye!");
		            writer.close();
		     String line;       
		     reader = new BufferedReader(new FileReader(MyFile));
			while((line=reader.readLine()) != null){
				char[] characters= line.toCharArray();
				for (int i = 0; i < characters.length; i++) {
					if(characters[i] == 'e')
						count++;
				}
			}
			System.out.println(count);
			
			reader.close();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
          
		
	}
	
	public static void main(String[] args) {
		countCharactersInFile('e',"file.txt");
	}

}
