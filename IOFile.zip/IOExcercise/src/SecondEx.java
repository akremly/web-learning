import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;

import javax.annotation.processing.Filer;
import javax.lang.model.element.Element;
import javax.tools.FileObject;
import javax.tools.JavaFileObject;
import javax.tools.JavaFileManager.Location;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class SecondEx {
	
	public static void main(String[] args) {
	
	//	insertUsers();
		
		readUsers();
	
	}

	
	
	/**
	 * 
	 */
	private static void readUsers() {
		List<User> users = new ArrayList<>();
		File file= new File("users.txt");
		try {
			BufferedReader  reader = new BufferedReader(new FileReader(file));
			
			String line;
			while((line=reader.readLine())!= null ){
			if(!line.isEmpty()){
				String[] details=line.split(",");
				
				
				users.add(new User(details[0],details[1],details[2]));
			}
			}
			reader.close();
			
			for (User user : users) {
				
			System.out.println(user);
				
			}
		} catch (FileNotFoundException e) {
			System.out.println("file not found");
		} catch (IOException e) {
	
			System.out.println("problem reading from the file");
		}
	}



	/**
	 * 
	 */
	private static void insertUsers() {
		String status="yes";
		try{
	Scanner in = new Scanner(System.in);
	File file=new File("users.txt");
	FileWriter writer= new FileWriter(file,true);
	
	StringBuilder userinfo=new StringBuilder();
	
	while(status.equals("yes")){
		writer.write("\r");
		System.out.println("Please enter User Name");
		userinfo.append(in.nextLine()+",");
		System.out.println("Please enter User address");
		userinfo.append(in.nextLine()+",");
		System.out.println("Please enter User email");
		userinfo.append(in.nextLine());
		writer.write(userinfo.toString());
		userinfo.setLength(0);
		 System.out.println("Please enter yes if you want to add more users");
		 status=in.nextLine();
	}
	writer.close();
		}catch(IOException e){
		
	}
		}
	
		
	}


