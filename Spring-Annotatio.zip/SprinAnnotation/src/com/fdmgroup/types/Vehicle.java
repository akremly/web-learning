package com.fdmgroup.types;

import org.springframework.beans.factory.annotation.Value;

public abstract class Vehicle {

	@Value("Toyota Corolla")
	private String model;
	@Value("4")
	private int numOfWheels;
	
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vehicle(String model, int numOfWheels) {
		super();
		this.model = model;
		this.numOfWheels = numOfWheels;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getNumOfWheels() {
		return numOfWheels;
	}

	public void setNumOfWheels(int numOfWheels) {
		this.numOfWheels = numOfWheels;
	}

	public void drive(){
		
	}
	
	public void park(){
		
	}
	@Override
	public String toString() {
		return "Vehicle [model=" + model + ", numOfWheels=" + numOfWheels + "]";
	}
	
	
}
