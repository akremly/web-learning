package com.fdmgroup.types;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class Car extends Vehicle {

	@Inject
	private Gear gear;
	
	@Value("Red")
	private String color;
	
	
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Car(String model, int numberOfWheels) {
		super(model, numberOfWheels);
	}
	
	
	@Override
	public String toString() {
		return "Car [gear=" + gear + ", color=" + color + "]";
	}


	@Override
	public void drive() {
	System.out.println("driving a vcar");
	}

	@Override
	public void park() {
		System.out.println("parking a vcar");
	}

	@PostConstruct
	public void myInit(){
		System.out.println("FURTHER INITIALIZATION OF MY CAR CLASS");
	}
	
	@PreDestroy
	public void myDestroy(){
		System.out.println("destroying MY CAR CLASS");
	}
	
}
