package com.fdmgroup.types;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Gear {
	
	public enum Transmission{
		AUTOMATIC, MANUAL
	}
	@Value("AUTOMATIC")
	private Transmission transmission;
	@Value("6")
	private int numOfGears;
	public Gear() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Gear(Transmission transmission, int numOfGears) {
		super();
		this.transmission = transmission;
		this.numOfGears = numOfGears;
	}
	public Transmission getTransmission() {
		return transmission;
	}
	public void setTransmission(Transmission transmission) {
		this.transmission = transmission;
	}
	public int getNumOfGears() {
		return numOfGears;
	}
	public void setNumOfGears(int numOfGears) {
		this.numOfGears = numOfGears;
	}
	@Override
	public String toString() {
		return "Gear [transmission=" + transmission + ", numOfGears=" + numOfGears + "]";
	}
	
	

}
