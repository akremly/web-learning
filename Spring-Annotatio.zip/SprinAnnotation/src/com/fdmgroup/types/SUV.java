package com.fdmgroup.types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("suv1")
public class SUV extends Vehicle{

	@Autowired
	public Gear gear;
	@Value("Blue")
	public String color;
	
	
	
	
	public SUV() {
		super();
		// TODO Auto-generated constructor stub
	}


	public SUV(String model, int numOfWheels) {
		super(model, numOfWheels);
		// TODO Auto-generated constructor stub
	}


	public SUV(Gear gear, String color) {
		super();
		this.gear = gear;
		this.color = color;
	}

	
	public Gear getGear() {
		return gear;
	}


	public void setGear(Gear gear) {
		this.gear = gear;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	@Override
	public void drive() {
		System.out.println("driving an SUV");
	}

	@Override
	public void park() {
		System.out.println("parking an SUV");
	}

	@Override
	public String toString() {
		return "SUV [gear=" + gear + ", color=" + color + "]";
	}

	
	
}
