package com.fdmgroup.types;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


public class Scooter extends Vehicle{
	
	private String color ;
	private Gear gear ;
	
	public Scooter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Scooter(String color) {
		super();
		this.color = color;
	}
	

	public Scooter(Gear gear) {
		super();
		this.gear = gear;
	}
	public Scooter(String model, int numberOfWheels) {
		super(model, numberOfWheels);
		
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Gear getGear() {
		return gear;
	}
	public void setGear(Gear gear) {
		this.gear = gear;
	}
	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return super.getModel();
	}
	@Override
	@Value("Vespa")
	public void setModel(String model) {
		// TODO Auto-generated method stub
		super.setModel(model);
	}
	@Override
	public int getNumOfWheels() {
		// TODO Auto-generated method stub
		return super.getNumOfWheels();
	}
	@Override
	@Value("2")
	public void setNumOfWheels(int numOfWheels) {
		// TODO Auto-generated method stub
		super.setNumOfWheels(numOfWheels);
	}
	@Override
	public void drive() {
		// TODO Auto-generated method stub
		super.drive();
	}
	@Override
	public void park() {
		// TODO Auto-generated method stub
		super.park();
	}
	@Override
	public String toString() {
		return "Scooter [color=" + color + ", getModel()=" + getModel() + ", getNumOfWheels()=" + getNumOfWheels()
				+ "]";
	}

	

}
