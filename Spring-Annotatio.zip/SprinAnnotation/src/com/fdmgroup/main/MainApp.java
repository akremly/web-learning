package com.fdmgroup.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.fdmgroup.config.DIConfigurator;
import com.fdmgroup.types.Car;
import com.fdmgroup.types.SUV;
import com.fdmgroup.types.Scooter;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context= new AnnotationConfigApplicationContext(DIConfigurator.class);
		
		Car car= context.getBean(Car.class);
		System.out.println(car);
		car.drive();
		
		System.out.println("-------------------------------------------------------------------------------");
		SUV suv= (SUV) context.getBean("suv1");
		System.out.println(suv);
		suv.drive();
		System.out.println("-------------------------------------------------------------------------------");
		Scooter scooter= context.getBean(Scooter.class);
		System.out.println(scooter);
		scooter.drive();
		System.out.println("-------------------------------------------------------------------------------");
		List<String> companies= (List<String>) context.getBean("companies");
		
		System.out.println(companies);
		
		
		((AnnotationConfigApplicationContext)context).close();
	}
}
