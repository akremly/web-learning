package com.fdmgroup.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.fdmgroup.types.Gear;
import com.fdmgroup.types.Scooter;

@Configuration
@ComponentScan(basePackages={"com.fdmgroup.types"})
public class DIConfigurator {

	@Bean
	public Scooter getScooter(Gear g){
	 Scooter scooter= new Scooter("Any Model", 2);	
	 scooter.setColor("Black");
	 scooter.setGear(g);
	 return scooter;
	}
	
	@Bean(name="companies")
	@Scope("singleton")
	public List<String> getCompanies(){
		List<String> companies= new ArrayList<>();
		companies.add("Toyota");
		companies.add("Ford");
		companies.add("Nissan");
		return companies;
	}
	
	
	
}
