package com.fdmgroup.client;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.Socket;

import java.util.Scanner;





public class Client {
	private static Socket clientSocket=null;
    
public static void main(String[] args) {
	
	String line;
	String message;
	Scanner ConsoleInput = new Scanner(System.in);
	try {
		clientSocket = new Socket("localhost", 5600);
		BufferedReader  streamInput = new BufferedReader(new InputStreamReader(  clientSocket.getInputStream()));
		PrintWriter streamOutput = new PrintWriter(clientSocket.getOutputStream(), true);
		System.out.println("Enter exit when you want to stop");
		System.out.println("Enter Username - This can be any name\n");
		while(true){
		streamOutput.println(ConsoleInput.nextLine());
		if(streamInput.readLine().equals("Accepted")){
			System.out.println("Username accepted");
			break;
			}
		System.out.println("Username is already taked enter different Username");
		}
		
		 new Sender(streamOutput).start();
		 new Reciever(streamInput).start();
		     	
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	

 }


public static class Sender extends Thread{
	private PrintWriter sender=null;
	private BufferedReader reader= null;
    private Scanner consoleInput= null;
    
	public Sender(PrintWriter sender) {
		super();
		this.sender = sender;
		consoleInput= new Scanner(System.in);
	}
    public void run() {
   String message;
    	while(true){
    		System.out.println("\r");
    		if((message=consoleInput.nextLine()).equals("exit")){
    			sender.close();
    			break;
    		}else{
    			sender.println(message);	
    		}
    				
    			
    	}
    	
    }
	
}

public static class Reciever extends Thread{
	private BufferedReader reader= null;
	private Scanner consoleInput= null;

	public Reciever(BufferedReader reader) {
		super();
		this.reader = reader;
		consoleInput= new Scanner(System.in);
	}
	
	  public void run() {
		  try {
		  while(true){
        	
        		
        		if(!clientSocket.isClosed()){
        			if(reader.ready()){
        			System.out.println(reader.readLine());
        			}else{
        				continue;
        			}
        
        			
        		}else{
        			reader.close();
        			break;
        		}
        	}
	
			} catch (IOException e) {
				e.printStackTrace();
			}
        
       
    	
	}
	  
	  
	
	
}


}
