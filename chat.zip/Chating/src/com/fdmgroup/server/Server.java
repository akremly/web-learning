package com.fdmgroup.server;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

public class Server {

  
    private static final int PORT = 5600;

    private static HashMap<String,PrintWriter> users = new HashMap<>();
   

    public static void main(String[] args) throws Exception {
        System.out.println("The chat server is running.");
        ServerSocket server = new ServerSocket(PORT);
        System.out.println("------- Usage Instruction ------");
        System.out.println("To send a message to all users type: all message ");
        System.out.println("To send a message to a specific user type: username message ");
        System.out.println("To ban a user type: ban username ");
        try {
        	
        	
        	 new Sender().start();
            while (true) {
            	Socket socket=server.accept();
            	  
                new ClientHandler(socket).start();
             
            }
        } finally {
            server.close();
        }
    }


    
    private static class ClientHandler extends Thread {
       private String userName;
        private Socket socket;
        private BufferedReader streamInput;
        private PrintWriter streamOutput;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

    
        public void run() {
            try {

        
            	streamInput = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            	streamOutput = new PrintWriter(socket.getOutputStream(), true);
            	

            	synchronized(users){
                while(true){
                userName=streamInput.readLine();
               if(users.containsKey(userName)){
            	   streamOutput.println("notAccepted"); 
            	   streamOutput.flush();
               }else{
            	 users.put(userName, streamOutput);  
            	 streamOutput.println("Accepted"); 
            	 streamOutput.flush();
            	 break;
               }
                
                }
            	}
            	
            	
  
                
                while (true) {
                	if(streamInput.ready()){
                    String input = streamInput.readLine();
                    if (input == null) {
                        return;
                    }
                    if(input.equals("exit")){
                    	users.remove(userName);
                    	try {
                            socket.close();
                        } catch (IOException e) {
                        }
                    }
                    for (Map.Entry<String, PrintWriter> writer : users.entrySet()) {
                    	if(!streamOutput.equals(writer.getValue()))
                    		writer.getValue().println("MESSAGE " +userName+  ": " + input);
                    	    writer.getValue().flush();
                    }
                	}
                }
            } catch (IOException e) {
                System.out.println(e);
            } 
        }
    }
    
    private static class Sender extends Thread{
    	
        private Scanner Input= null;
        
    	public Sender() {
    		super();    	
    		Input= new Scanner(System.in);
    	}
        public void run() {
        	while(true){
        	System.out.println("\r\n");
        	String Message=Input.nextLine();
        	String msg[] = Message.split(" ", 2);
        	if(msg[0].equals("all")){
        		for (Map.Entry<String, PrintWriter> writer : users.entrySet()) {
                		writer.getValue().println("Messager from Admin: " + msg[1]);
                		writer.getValue().flush();
                } 	
                }else if (msg[0].equals("ban")){
      
                		users.get(msg[1]).println("Messager from Admin: you are banned");
                		users.remove(msg[1]).close();
        	    }else if (users.containsKey(msg[0])){
        	    	users.get(msg[0]).println("Messager from Admin: " +msg[1]);	
        	    }
        
        	}
        	
        }
    	
    }
}