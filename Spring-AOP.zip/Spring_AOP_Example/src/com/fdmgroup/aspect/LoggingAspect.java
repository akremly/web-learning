package com.fdmgroup.aspect;

public class LoggingAspect {
	
	
	public void logBefore(){
		System.out.println("Logging before a method (using xml)");
	}
	public void logAfter(){
		System.out.println("Logging After a method (using xml)");
	}
	public void logAfterThrow(){
		System.out.println("Logging After throwing exception (using xml)");
	}
	public void logAfterReturn(){
		System.out.println("Logging after successful return (using xml)");
	}

}
