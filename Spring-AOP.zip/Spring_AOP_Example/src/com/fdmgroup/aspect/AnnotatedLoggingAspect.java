package com.fdmgroup.aspect;


import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AnnotatedLoggingAspect {


	@Pointcut("execution (* com.fdmgroup.service.*.*(..))")
	public void log(){}
	

	@Pointcut("execution (* com.fdmgroup.service.ShoppingCart.loop())")
	public void profiler(){}
	
	
	@Before("log()")
	public void logBefore(JoinPoint jp){
		System.out.println("logging before a method ..."+ jp.getSignature().getName()+"-------"+Arrays.toString(jp.getArgs()));
	}
	
	@After("log()")
	public void logAfter(JoinPoint jp){
		System.out.println("logging after a method ..."+ jp.getSignature().getName()+"-------"+Arrays.toString(jp.getArgs()));
	}
	
	@AfterThrowing("log()")
	public void logAfterThrow(JoinPoint jp){
		System.out.println("logging after throwing an exception in method ..."+ jp.getSignature().getName()+"-------"+Arrays.toString(jp.getArgs()));
	}
	@AfterReturning("log()")
	public void logAfterRetruning(JoinPoint jp){
		System.out.println("logging after returning from method ..."+ jp.getSignature().getName()+"-------"+Arrays.toString(jp.getArgs()));
	}
	
	@Around("profiler()")
	public void logAround(ProceedingJoinPoint jp){
		System.out.println("[Profiler:] Starting the profiler . . . .");
		
		long startTime= System.nanoTime();
		Object rVal=null;
		try {
			rVal=jp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		long endTime= System.nanoTime();
		
		System.out.println("[Profiler:] Terminating");
		System.out.println("[Profiler:] execution of "+jp.getSignature().getName()+" method took"+(startTime-endTime)+ " nanoseconds. The return Value is "+rVal.toString());
	}
}
