package com.fdmgroup.service;

import org.springframework.cache.interceptor.CacheOperationInvoker.ThrowableWrapper;
import org.springframework.stereotype.Component;

@Component
public class ShoppingCart {

	public void addItem(String item, int quantity){
		System.out.println(quantity+" Units of "+ item+ " are added to the cart");
	}
	
	public void removeItem(String item){
		System.out.println(item+" removed from the cart");
	}
	public void removeAll() throws Exception{
		System.out.println("All items removed from the cart");
		throw new Exception("General Exception");
	}
	
	public Integer loop(){
		int sum=0;
		for (int i = 0; i < 11; i++) {
			sum+=i;
			System.out.println(i+", ");
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		return sum;
	}
}
