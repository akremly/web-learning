package com.fdmgroup.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan(basePackages={"com.fdmgroup.service","com.fdmgroup.aspect"})
@EnableAspectJAutoProxy
public class AppConfigurator {

}
