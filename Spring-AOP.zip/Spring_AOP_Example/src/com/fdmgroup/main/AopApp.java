package com.fdmgroup.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fdmgroup.config.AppConfigurator;
import com.fdmgroup.service.ShoppingCart;

public class AopApp {

	public static void main(String[] args) {
	//	ApplicationContext context= new AnnotationConfigApplicationContext(AppConfigurator.class);
		ApplicationContext context= new ClassPathXmlApplicationContext("spring-config.xml");
		
		//ShoppingCart cart=context.getBean(ShoppingCart.class);
		ShoppingCart cart=(ShoppingCart)context.getBean("shoppingCart");
	//	cart.loop();
		cart.addItem("Iphone 7", 9000000);
		cart.removeItem("Iphone 7");
		try {
			cart.removeAll();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		//((AnnotationConfigApplicationContext)context).close();
		((ClassPathXmlApplicationContext)context).close();
	}
}
