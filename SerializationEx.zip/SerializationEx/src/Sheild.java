import java.io.Serializable;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Sheild implements Serializable{
private String shieldName;
private String sheildType;


public Sheild(String shieldName, String sheildType) {
	super();
	this.shieldName = shieldName;
	this.sheildType = sheildType;
}


public String getShieldName() {
	return shieldName;
}


public String getSheildType() {
	return sheildType;
}


public void setShieldName(String shieldName) {
	this.shieldName = shieldName;
}


public void setSheildType(String sheildType) {
	this.sheildType = sheildType;
}


@Override
public String toString() {
	return "Sheild [shieldName=" + shieldName + ", sheildType=" + sheildType + "]";
}



}
