import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fdmgroup.serialization.game.*;




/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Wizard extends Player implements Serializable{
	
	private   List< Sheild> shields;
	private  List<Power> powers;
	private transient Backpack backPack;
 private static final long serialVersionUID = 1;

	
	public Wizard() {
		super();
		shields= new ArrayList<>();
		powers= new ArrayList<>();
	}
	
public void addShield(Sheild s){
		this.shields.add(s);
	}
public void addPower(Power p){
	this.powers.add(p);
}
	
	public List<Sheild> getShields() {
		return shields;
	}
	public List<Power> getPowers() {
		return powers;
	}
	public Backpack getBackPack() {
		return backPack;
	}
	public void setShields(List<Sheild> shields) {
		this.shields = shields;
	}
	public void setPowers(List<Power> powers) {
		this.powers = powers;
	}
	public void setBackPack(Backpack backPack) {
		this.backPack = backPack;
	}
	
	
	private void writeObject(ObjectOutputStream out) 
			throws IOException{
		int packs= this.getBackPack().getNumPacks();
		out.defaultWriteObject();
		out.writeUTF(this.getName());
		out.writeInt(this.getHealthPoints());
		out.writeInt(this.getBackPack().getNumPacks());
		for (int i = 0; i <packs; i++) {
			out.writeInt(this.getBackPack().useHealthPack().getHealthPoints());	
		}
		out.writeObject(this.getPowers());
		out.writeObject(this.getShields());
	}
	private void readObject(ObjectInputStream in) 
			throws IOException, ClassNotFoundException
			{
		in.defaultReadObject();
		this.setName((String) in.readUTF());
		this.setHealthPoints(in.readInt());
		this.backPack = new Backpack();
		int numOfPacks= in.readInt();
		for (int i = 0; i < numOfPacks; i++) {
		this.backPack.addHealthPack( new HealthPack(in.readInt()));	
		}
		
		this.setPowers((List<Power>) in.readObject());
		this.setShields((List<Sheild>) in.readObject());
			}
	
	
	
	
	

}
