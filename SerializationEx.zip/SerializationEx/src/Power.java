import java.io.Serializable;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Power implements Serializable {
	private String powerName;
	private String powertype;
	private String powerLevel;
	
	
	public Power(String powerName, String powertype, String powerLevel) {
		super();
		this.powerName = powerName;
		this.powertype = powertype;
		this.powerLevel = powerLevel;
	}


	public String getPowerName() {
		return powerName;
	}


	public String getPowertype() {
		return powertype;
	}


	public String getPowerLevel() {
		return powerLevel;
	}


	public void setPowerName(String powerName) {
		this.powerName = powerName;
	}


	public void setPowertype(String powertype) {
		this.powertype = powertype;
	}


	public void setPowerLevel(String powerLevel) {
		this.powerLevel = powerLevel;
	}


	@Override
	public String toString() {
		return "Power [powerName=" + powerName + ", powertype=" + powertype + ", powerLevel=" + powerLevel + "]";
	}
	
	
	
	
	

}
