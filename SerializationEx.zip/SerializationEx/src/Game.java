import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.omg.CORBA.BAD_INV_ORDER;

import com.fdmgroup.serialization.game.Backpack;
import com.fdmgroup.serialization.game.Board;
import com.fdmgroup.serialization.game.HealthPack;
import com.fdmgroup.serialization.game.Player;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Game {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
	final String LOCATION="players.txt";
	
	Sheild shield1= new Sheild("shield1", "strong");
	Sheild shield2= new Sheild("shield2", "week");
	
	// Player 1
	Wizard player1= new Wizard();
	player1.addShield(shield1);
	player1.setName("Akrem");
	player1.setHealthPoints(100);
	Backpack backpack1= new Backpack();
	HealthPack healthback1= new HealthPack();
	healthback1.setHealthPoints(100);
	backpack1.addHealthPack(healthback1);
    player1.setBackPack(backpack1);
    
    //Player2
	Wizard player2= new Wizard();
    player2.addShield(shield2);
    player2.addShield(shield1);
	player2.setName("Hosam");
	player2.setHealthPoints(100);
	Backpack backpack2= new Backpack();
	HealthPack healthback2= new HealthPack();
	healthback2.setHealthPoints(100);
	HealthPack healthback3= new HealthPack();
	healthback3.setHealthPoints(90);
	backpack2.addHealthPack(healthback2);
	backpack2.addHealthPack(healthback3);
    player2.setBackPack(backpack2);
    
    // start game
	Board board = new Board();

	board.attack(player1, player2);
	board.defend(player1, player2);
	board.loseHealthPoint(player2);


	//serilaize player2
	try(FileOutputStream fo= new FileOutputStream(LOCATION); ObjectOutputStream os= new ObjectOutputStream(fo); ){
		os.writeObject(player2);
	} catch (FileNotFoundException e) {

		e.printStackTrace();
		e.getMessage();
	} catch (IOException e) {
	
		e.printStackTrace();
		e.getMessage();
	}
	//deserialize player2
	try(FileInputStream fi= new FileInputStream(LOCATION); ObjectInputStream is=new ObjectInputStream(fi);){
		Wizard deserializedPlayer= (Wizard) is.readObject();
		System.out.println("---------------------------------------");
		System.out.println("Player name: "+deserializedPlayer.getName());
		System.out.println("Number of points: "+deserializedPlayer.getHealthPoints());
		System.out.println("Available sheilds for the player: "+deserializedPlayer.getShields());
		System.out.println("Number of healthPacks the user has "+deserializedPlayer.getBackPack().getNumPacks());

	
	} catch (FileNotFoundException e) {
		e.printStackTrace();
		e.getMessage();
	} catch (IOException e) {
		e.printStackTrace();
		e.getMessage();
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
		e.getMessage();
	}
	}

}
