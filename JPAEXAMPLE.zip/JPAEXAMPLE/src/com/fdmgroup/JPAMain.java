package com.fdmgroup;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.fdmgroup.model.Company;
import com.fdmgroup.model.Role;
import com.fdmgroup.model.Stock;
import com.fdmgroup.model.User;
import com.fdmgroup.model.UserProfile;

public class JPAMain {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("JPAEXAMPLE");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Role role1= new Role("Admin");
		Role role2= new Role("Master");
		
		List<Role> roles1= new ArrayList<>();
		List<Role> roles2= new ArrayList<>();
		List<Role> roles3= new ArrayList<>();
		
		roles1.add(role1);
		roles2.add(role2);
		roles3.add(role1);
		roles3.add(role2);
		
		Stock s1= new Stock("GGL");
		Stock s2= new Stock("FB");
		Stock s3= new Stock("LNKDN");
		Stock s4= new Stock("TWT");
		
		Company c1= new Company("Google","California, Mountainview", new Date(1998,7,1), s1);
		Company c2= new Company("Facebook","Menlopark", new Date(2004,11,5), s2);
		Company c3= new Company("LinkedIn","California, Mountainview", new Date(2005,3,4), s3);
		Company c4= new Company("Twitter","SanFrancisco", new Date(2006,6,8), s4);
		
		User user1= new User("will", "1234", "william", "Zhao", new UserProfile("Mississauga",23,"Bicycle"), roles1, c1);
		User user2=new User("sheh", "12345", "shehrear", "Awan", new UserProfile("Toronto",24,"Train"), roles2, c2);
		User user3=new User("joseph", "9872", "Chomin", "Yen", new UserProfile("Burlington",24,"Focus"), roles3, c3);
		User user4=new User("Akrem", "12345", "akrem", "Latiwesh", new UserProfile("Toronto",24,"car"), roles3, c4);
		
		entityManager.persist(role1);
		entityManager.persist(role2);
		
		
		entityManager.persist(s1);
		entityManager.persist(s2);
		entityManager.persist(s3);
		entityManager.persist(s4);
		
		entityManager.persist(c1);
		entityManager.persist(c2);
		entityManager.persist(c3);
		entityManager.persist(c4);
		
		entityManager.persist(user1);
		entityManager.persist(user2);
		entityManager.persist(user3);
		entityManager.persist(user4);
		
		transaction.commit();
		
		entityManager.close();
		entityManagerFactory.close();
	}
}
