package com.fdmgroup;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.fdmgroup.model.User;

public class JPAQueryMain {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAEXAMPLE");
		EntityManager em=emf.createEntityManager();
		EntityTransaction transaction=em.getTransaction();
		
		
		TypedQuery<User> query=em.createNamedQuery("user.findAll", User.class);
		List<User> resultList=query.getResultList();
		
		
		for (User user : resultList) {
			System.out.println(user);
		}
		System.out.println("````````````````````````````````````````````````````````");
		
		TypedQuery<User> query2=em.createNamedQuery("user.findByUsername", User.class);
		query2.setParameter("uname", "will");
		List<User> user2=query2.getResultList();
		
		if(user2.size()==1)
			System.out.println(user2.get(0));
		else
			System.out.println("User not found");
		
		
		System.out.println("````````````````````````````````````````````````````````");
		
		TypedQuery<User> query3=em.createNamedQuery("user.findByAddress", User.class);
		query3.setParameter("uadd", "To%");
		
		List<User> user3=query3.getResultList();
		
		for (User user : user3) {
			System.out.println(user);
		}
		
		
	}
}
