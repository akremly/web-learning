package com.fdmgroup.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="tbl_company")
@SecondaryTables({@SecondaryTable(name="tbl_company_profile", pkJoinColumns=@PrimaryKeyJoinColumn)})
public class Company {

	@Id
	@Column(name="company_id")
	@SequenceGenerator(name="my_seq1_com", sequenceName="My_JPA_Sequence")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq1_com")
	private int id;
	
	@Column
	private String name; 
	
	@Column(table="tbl_company_profile")
	private String address; 
	
	@Column(table="tbl_company_profile")
	@Temporal(TemporalType.DATE)
	private Date established;
	
	@OneToMany(mappedBy="company")
	private List<User> users;
	
	@OneToOne(fetch=FetchType.LAZY)
	private Stock stock;

	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Company(String name, String address, Date established, Stock stock) {
		super();
		
		this.name = name;
		this.address = address;
		this.established = established;
		this.users = users;
		this.stock = stock;
	}

	@Override
	public int hashCode() {
	final int prime=31;
	int result=31;
	result=prime*result+id;
	result=prime*result+((name==null)?0:name.hashCode());
	
		return result;
	}

	@Override
	public boolean equals(Object obj) {
      if(this==obj)
    	  return true;
      if(obj==null)
    	  return false;
      if(getClass() != obj.getClass())
    	  return false;
      
      Company other= (Company) obj;
      
      if(id != other.id)
    	  return false;
      if(name==null){
    	  if(other.name!=null)
    		  return false;
      }  else if(!name.equals(other.name)){
    	  return false;
      }
		return true;
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", name=" + name + ", address=" + address + ", established=" + established + "]";
	}

	
	
	
	
}
