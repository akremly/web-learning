package com.fdmgroup.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TBL_Java17")
@NamedQueries({
    @NamedQuery(name = "user.findAll", query = "SELECT u FROM User u"),
    @NamedQuery(name = "user.findByUsername", query = "SELECT u FROM User u WHERE u.userName = :uname"),
    @NamedQuery(name = "user.findByAddress", query = "SELECT u FROM User u WHERE u.userProfile.address LIKE :uadd"),
    
})

public class User {

	@Id
	@Column(name="user_id")
	@SequenceGenerator(name="me_seq", sequenceName="My_JPA_Sequence")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="me_seq")
	private int id;
	
	@Column(name="user_name", length=50, nullable=false)
	private String userName;
	
	@Column(name="pw", length=30, nullable=false)
	private String passowrd;
	
	@Column
	private String firstname;
	
	@Column
	private String lastname;
	
	@Embedded
	private UserProfile userProfile;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	@JoinTable(name="TBL_USER_ROLE")
	private List<Role> roles;
	
     @ManyToOne(fetch=FetchType.LAZY)
	private Company company;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User( String userName, String passowrd, String firstname, String lastname, UserProfile userProfile,
			List<Role> roles, Company company) {
		super();
	
		this.userName = userName;
		this.passowrd = passowrd;
		this.firstname = firstname;
		this.lastname = lastname;
		this.userProfile = userProfile;
		this.roles = roles;
		this.company = company;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassowrd() {
		return passowrd;
	}

	public void setPassowrd(String passowrd) {
		this.passowrd = passowrd;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", passowrd=" + passowrd + ", firstname=" + firstname
				+ ", lastname=" + lastname + "]";
	}

	
     
}


