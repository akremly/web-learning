import java.util.List;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public interface ReadItemCommand {
	
	public List<Book> readAll();

}
