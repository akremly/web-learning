/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public interface WriteItemCommand {

	
void insertItem(Book book);	
}
