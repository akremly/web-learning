/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Book {
	
private String title;

public Book(String title) {
	super();
	this.title = title;
}

}
