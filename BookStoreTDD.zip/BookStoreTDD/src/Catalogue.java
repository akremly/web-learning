import java.util.ArrayList;
import java.util.List;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Catalogue implements ReadItemCommand, WriteItemCommand{
  private List<Book> booksCatalogue;
  private ReadItemCommand readItemCommand;
  private WriteItemCommand writeItemCommand;
  
	public Catalogue(ReadItemCommand readItemCommand, WriteItemCommand writeItemCommand) {
	//super();
	this.readItemCommand=readItemCommand;
	this.writeItemCommand =writeItemCommand;
	this.booksCatalogue = new ArrayList<Book>();
}


	/**
	 * @return
	 */
	public List<Book> getAllBooks() {
		return this.readItemCommand.readAll();
		
	}


	/* (non-Javadoc)
	 * @see ReadItemCommand#readAll()
	 */
	@Override
	public List<Book> readAll() {
		// TODO Auto-generated method stub
		return booksCatalogue;
	}


	/* (non-Javadoc)
	 * @see WriteItemCommand#insertItem(Book)
	 */
	@Override
	public void insertItem(Book book) {
		// TODO Auto-generated method stub
		
	}


	/**
	 * 
	 */
	public void addBook(Book book) {
		
		this.writeItemCommand.insertItem(book);	
	}




	


	
	

}
