/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Checkout {

	/**
	 * @param basket
	 * @return
	 */
	public double calculatePrice(Basket<Book> basket) {
		int size= basket.getBooksInBasket().size();
    if(size != 0){
    	if(size<3){
    		return 25.99;
    	}else if (size >=3){
    		int discount = size/3;
    		
    		if(size >=10)
    			discount+=10;
    		
    		System.out.println(discount);
    		double OriginalPrice=25.99*size;
    		double PriceAfterDiscount= OriginalPrice-OriginalPrice*((double)discount/100);
    		System.out.println(PriceAfterDiscount);
    		return PriceAfterDiscount;
    	}
    }
    	return 0.0;
	}

}
