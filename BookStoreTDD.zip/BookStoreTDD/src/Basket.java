
import java.util.ArrayList;
import java.util.List;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class Basket<T> {
private List<T> booksInBasket;


	public Basket() {
	super();
	this.booksInBasket = new ArrayList<>();
}

	/**
	 * @param <T>
	 * @return
	 */
	public List<T> getBooksInBasket() {
	
		return booksInBasket;
	}

	/**
	 * 
	 */
	public void addBook(T book) {
		this.booksInBasket.add(book);
		
	}

}
