import static org.junit.Assert.*;

import java.lang.reflect.Array;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BasketTest {
	
private static Basket<Book> basket;


@BeforeClass
public static void setup(){
	 basket= new Basket();
	 basket.addBook(new Book("History of Libya"));
	 basket.addBook(new Book("History of Canada"));
}


@Test
public void test_test_GetBooksInBasket_ReturnsArrayOfLengthTwo_AfterAddBookMethodIsCalledWithTwoBooks(){ 
	int size= ( basket.getBooksInBasket()).size();
	assertEquals(size,2);
}

@Test
public void test_GetBooksInBasket_ReturnsArrayOfLengthOne_AfterAddBookMethodIsCalledWithOneBook(){
	 int size= ( basket.getBooksInBasket()).size();
		assertEquals(size,1);
}

@Test
public void test_GetBooksInBasket_ReturnsEmptyBookList_IfNoBooksHaveBeenAdded(){
	int size= ( basket.getBooksInBasket()).size();
	assertEquals(size,0);
}

}
