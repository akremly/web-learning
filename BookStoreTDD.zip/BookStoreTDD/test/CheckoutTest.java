import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class CheckoutTest {
	
private static Checkout checkout;
private static Basket<Book> basket;

@BeforeClass
public static void setup(){
	basket= new Basket<>();
	basket.addBook(new Book("Hostory"));
	basket.addBook(new Book("Math"));
	basket.addBook(new Book("English"));
	basket.addBook(new Book("Hostory II"));
	basket.addBook(new Book("Math II"));
	basket.addBook(new Book("English II"));
	basket.addBook(new Book("Science II"));
	basket.addBook(new Book("Math III"));
	basket.addBook(new Book("English III"));
	basket.addBook(new Book("ScienceI"));
	basket.addBook(new Book("English IV"));
	basket.addBook(new Book("ScienceIII"));
	checkout= new Checkout();
}

@Test
public void test_CalculatePrice_ReturnsDoubleZeroPointZeroWhenPassedAnEmptyBasket(){
	double price=checkout.calculatePrice(basket);
	assertEquals(price,0.0,0.01);
}

@Test
public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithOneBook(){
	double price=checkout.calculatePrice(basket);
	assertEquals(price,25.99,0.01);	
}

@Test
public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithThreeBooks(){
	double price=checkout.calculatePrice(basket);
	assertEquals(price,77.19,0.01);	
}

@Test
public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithSevenBooks(){
	double price=checkout.calculatePrice(basket);
	assertEquals(price,178.29,0.01);	
}

@Test
public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithTenBooks(){
	double price=checkout.calculatePrice(basket);
	assertEquals(price,268.21,0.01);	
}

@Test
public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithTwelveBooks(){
	double price=checkout.calculatePrice(basket);
	assertEquals(price,245.86,0.01);	
}
}
