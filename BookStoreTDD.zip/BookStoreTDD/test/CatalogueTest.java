import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;
import  org.mockito.Mock;
import org.mockito.*;



/**
 * 
 */

/**
 * @author akrem.latiwesh
 *
 */
public class CatalogueTest {

	
	
	@Mock
	private static ReadItemCommand mockReadItemCommandObject;
	
	@Mock
	private static WriteItemCommand mockWriteItemCommand;
	
	@Mock
	private static Book book;
	
	@Mock
	private  List<Book> mockBookList= new ArrayList<Book>();
	
	private Catalogue catalogue= new Catalogue(mockReadItemCommandObject,mockWriteItemCommand);
	
	@BeforeClass
	public static void setup(){
		
		CatalogueTest cat= new CatalogueTest();
		MockitoAnnotations.initMocks(cat);
		
	}
	

	
	@Test 
	public void test_GetAllBooks_CallsReadAllMethodOfReadItemCommand_WhenCalled(){
		catalogue.getAllBooks();
		verify(mockReadItemCommandObject, times(2)).readAll() ;
		
	}
	
	@Test 
	public void test_GetAllBooks_ReturnsListOfBooksItReceivesFromReadAllMethodOfReadItemCommand_WhenCalled(){
		List<Book> actualBookList=catalogue.getAllBooks();
		when(mockReadItemCommandObject.readAll()).thenReturn(mockBookList);
		assertEquals(mockBookList, actualBookList);
		
	}
	
	@Test
	public void test_AddBook_CallsInsertItemMethodOfWriteItemCommand_WhenCalled(){
		catalogue.addBook(book);
		verify(mockWriteItemCommand, times(1)).insertItem(book) ;
	}


}
