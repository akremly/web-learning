package com.fdmgroup.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

public class Calculator {

	@Range(min=100, max=1000, message="the number provided is not within the range 100-1000")
	@NotNull(message="this parameter can not be null")
	private int number1;
	
	@Digits(integer=6, fraction=0, message="this is not a valid integer")
	@NotNull(message="this parameter can not be null")
	private int number2;

	public Calculator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getNumber1() {
		return number1;
	}

	public void setNumber1(int number1) {
		this.number1 = number1;
	}

	public int getNumber2() {
		return number2;
	}

	public void setNumber2(int number2) {
		this.number2 = number2;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + number1;
		result = prime * result + number2;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Calculator other = (Calculator) obj;
		if (number1 != other.number1)
			return false;
		if (number2 != other.number2)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Calculator [number1=" + number1 + ", number2=" + number2 + "]";
	}

	public int add(){
		return number1+number2;
	}
	public int sub(){
		return number1-number2;
	}
	public int mul(){
		return number1*number2;
	}
	public double div(){
		if(number2==0)
			return 0;
		
		return number1+number2;
	}
	
	
}
