package com.fdmgroup.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;

import com.fdmgroup.model.User;

public class UserDaoImpl implements IUserDao {
	@Autowired
	DBConnection dbConnection;

	@Override
	public List<User> findAll() {
		EntityManager em=dbConnection.getEntityManager();
		TypedQuery<User> query= em.createNamedQuery("user.findAll", User.class);
		
		return query.getResultList();
	}

	@Override
	public User findById(int id) {
		EntityManager em=dbConnection.getEntityManager();
		return em.find(User.class, id);
	}

	@Override
	public User findByUsername(String username) {
		EntityManager em=dbConnection.getEntityManager();
		TypedQuery<User> query= em.createNamedQuery("user,findByUsername", User.class);
		query.setParameter("uname", username);
		List<User> users=query.getResultList();
		if(users!=null && users.size()==1)
			return users.get(0);
		
		return null;
	}

}
