package com.fdmgroup.dao;
import java.util.List;

import com.fdmgroup.model.User;
public interface IUserDao {

	List<User> findAll();
	User findById(int id);
	User findByUsername(String username);
}
