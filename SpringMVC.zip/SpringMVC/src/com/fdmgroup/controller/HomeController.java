package com.fdmgroup.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fdmgroup.model.Calculator;

@Controller
public class HomeController {

	@RequestMapping(value="/home")
	public String showHome(Model model){
		model.addAttribute("cal", new Calculator());
		return "home";
	}
	@RequestMapping(value="/proccessForm", method={RequestMethod.GET,RequestMethod.POST})
	public String processForm(Model model, @Valid @ModelAttribute(value="cal") Calculator cal, BindingResult br){
		
		if(br.hasErrors()){
			model.addAttribute("cal", cal);
			return "home";}
		model.addAttribute("sum", cal.add());
		return "calculate";
	}
	
	@RequestMapping(value="/welcome/{userId}", method=RequestMethod.GET)
	public String showWelcome(@PathVariable int userId){
	System.out.println("The user id is: "+ userId);	
	
	return "welcome";
	}
}
