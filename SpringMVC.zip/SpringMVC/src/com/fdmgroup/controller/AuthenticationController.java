package com.fdmgroup.controller;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.fdmgroup.dao.IUserDao;
import com.fdmgroup.model.User;

@Controller
@SessionAttributes(value={"user"}, types={User.class})
public class AuthenticationController {

	@Autowired
	private IUserDao userDao;
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String showLogin(Model model){
		model.addAttribute("user", new User());
		return "login";
	}
	
	@RequestMapping(value="/proccessLogin", method=RequestMethod.POST)
	public String proccessLogin(Model model, @Valid @ModelAttribute(value="user") User user, BindingResult br){
		
		if(br.hasErrors())
			return "login";
		
		
		User foundUser=userDao.findByUsername(user.getUsername());
		if(foundUser!= null && foundUser.getPassword().equals(user.getPassword())){
			model.addAttribute("user", foundUser);
			return "welcome";
		}
		model.addAttribute("errorMessage", "Username/Password is wrong");
		return "login";
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(SessionStatus ss){
		ss.setComplete();
		return "forward:/login";
	}
	
}
