package com.fdm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="TBL_USR")
@NamedQueries({@NamedQuery(name="trainee.findByTraineeName",query="SELECT t FROM Trainee t WHERE t.username=:tname"),
	@NamedQuery(name="trainee.findAll",query="select t from Trainee t")})
public class Trainee {
@Id
@Column(name="USERID")
//@GeneratedValue(strategy=GenerationType.AUTO)
private int id;

@Column(name="USERNAME")
private String username;

@Column(name="PW")
private String password;

@Column(name="FIRSTNAME")
private String firstname;

@Column(name="LASTNAME")
private String lastname;

public Trainee() {
	super();
	// TODO Auto-generated constructor stub
}



public Trainee(String username, String password, String firstname, String lastname) {
	super();
	this.username = username;
	this.password = password;
	this.firstname = firstname;
	this.lastname = lastname;
}



public int getId() {
	return id;
}



public void setId(int id) {
	this.id = id;
}



public String getUsername() {
	return username;
}



public void setUsername(String username) {
	this.username = username;
}



public String getPassword() {
	return password;
}



public void setPassword(String password) {
	this.password = password;
}



public String getFirstname() {
	return firstname;
}



public void setFirstname(String firstname) {
	this.firstname = firstname;
}



public String getLastname() {
	return lastname;
}



public void setLastname(String lastname) {
	this.lastname = lastname;
}






}
