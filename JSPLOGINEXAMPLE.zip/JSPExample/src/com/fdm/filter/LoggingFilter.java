package com.fdm.filter;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.fdm.model.AppLogger;

/**
 * Servlet Filter implementation class LoggingFilter
 */
@WebFilter("/LoggingFilter")
public class LoggingFilter implements Filter {

    /**
     * Default constructor. 
     */
    public LoggingFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		String ip=request.getRemoteAddr();
		String rescource=((HttpServletRequest)request).getRequestURL().toString();
		
		AppLogger.getSysLogger().info(ip+"--------------->"+LocalDate.now()+"----->" +LocalTime.now()+"---->"+rescource);
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
//		AppLogger.getSysLogger().info("loggingFilter initialized");
	}

}
