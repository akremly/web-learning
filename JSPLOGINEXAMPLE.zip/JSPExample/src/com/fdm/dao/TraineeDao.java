package com.fdm.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.fdm.model.Trainee;

public class TraineeDao {

	private static TraineeDao userDao=null;
	private DataAccessObject dao=null;
	public TraineeDao() {
	dao=DataAccessObject.getInstance();
	}
	
	public static TraineeDao getInstance(){
		if(userDao==null)
			userDao= new TraineeDao();
		return userDao;
	}
	
	public Trainee findByTraineeName(String name){
	EntityManager em = dao.getConnection();
	//TypedQuery<Trainee> query= em.createNamedQuery("trainee.findByTraineeName",Trainee.class);
	Query query= em.createQuery("SELECT t FROM Trainee t WHERE t.username=:tname",Trainee.class);
	
	query.setParameter("tname", name);
	
	List<Trainee> trainees= query.getResultList();
	
	if(trainees.size()==1)
		return trainees.get(0);
	else 
		return null;
	}
	
	public Trainee findById(int id){
		EntityManager em = dao.getConnection();
		return em.find(Trainee.class, id);
		}
	public List<Trainee> findAll(){
		EntityManager em = dao.getConnection();
		TypedQuery<Trainee> query= em.createNamedQuery("trainee.findAll",Trainee.class);
		
		return query.getResultList();
		}
}
