/**
 * 
 */
package com.fdmgroup;

/**
 * @author akrem.latiwesh
 *
 */
public class Driver {
	
	private String name;
	private String licenseNumber;
	
	
	public Driver(String name, String licenseNumber) {
		super();
		this.name = name;
		this.licenseNumber = licenseNumber;
	}


	public Driver(){
		super();
	
	}


	public String getName() {
		return name;
	}


	public String getLicenseNumber() {
		return licenseNumber;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}


	@Override
	public String toString() {
		return "Driver [name=" + name + ", licenseNumber=" + licenseNumber + "]";
	}
	
	
	
	
	

}
