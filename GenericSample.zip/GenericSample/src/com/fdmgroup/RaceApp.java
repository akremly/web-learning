/**
 * 
 */
package com.fdmgroup;

import javax.swing.plaf.synth.SynthSeparatorUI;

/**
 * @author akrem.latiwesh
 *
 */
public class RaceApp {
	
public static void main(String[] args) {
	
	Race<Driver, Suv> race= new Race<>();
	
	Driver driver1= new Driver("Joseph Yen","007");
	Driver driver2= new Driver("Maguel","0011");
	Driver driver3= new Driver("Akrem Latiwesh","008");
	
	Driver driver4= new Driver("William Zhao","009");
	Driver driver5= new Driver("Arjun ","013");
	Driver driver6= new Driver("Dominic ","00Fung");
	Driver driver7= new Driver("Ammar ","0010");
	
	Driver driver8= new Driver("Joseph Yen","332");
	Driver driver9= new Driver("Joseph Yen","420");
	Driver driver10= new Driver("Joseph Yen","23");
	
	Suv suv1= new Suv("Honda Civic", "SUV");
	Suv suv2= new Suv("Toyota Camery", "SUV");
	Suv suv3= new Suv("BMW-M4", "SUV");
	
	Suv suv4= new Suv("Bycicle", "SUV");
	Suv suv5= new Suv("OB3", "SUV");
	Suv suv6= new Suv("Porsche", "SUV");
	Suv suv7= new Suv("Cadelace", "SUV");
	
	Suv suv8= new Suv("Tesla", "SUV");
	Suv suv9= new Suv("Boggati", "SUV");
	Suv suv10= new Suv("Ford Fusion", "SUV");
	
	race.addRacer(driver1, suv1);
	race.addRacer(driver2, suv2);
	race.addRacer(driver3, suv3);
	race.addRacer(driver4, suv4);
	race.addRacer(driver5, suv5);
	race.addRacer(driver6, suv6);
	race.addRacer(driver7, suv7);
	race.addRacer(driver8, suv8);
	race.addRacer(driver9, suv9);
	race.addRacer(driver10, suv10);

	System.out.println("The winner is : "+race.announceWinner());
	
	
}
}
