/**
 * 
 */
package com.fdmgroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * @author akrem.latiwesh
 *
 */
public class Race<K extends Driver, V extends Vehicle & AllWheelDrivable> {

	private List<K> drivers;
	private Map<K, V> racers;
	
	
	public Race() {
		super();
		this.drivers = new ArrayList<>();
		this.racers = new HashMap<>();
	}


	public void addRacer(K driver, V vehicle){
		drivers.add(driver);
		racers.put(driver, vehicle);
	}
	
	public List<K> getDrivers() {
		return drivers;
	}


	public K announceWinner(){
		
		Random r= new Random();
		int winner=r.nextInt(drivers.size());
		return drivers.get(winner);
		
	
	}
	
	
	
}
