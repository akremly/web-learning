/**
 * 
 */
package com.fdmgroup;

/**
 * @author akrem.latiwesh
 *
 */
public class Car extends Vehicle {
	
	

	public Car() {
		super();
		
	}

	public Car(String name, String type) {
		super(name, type);
	}

	public Car(String name, String type, int numberOfWheels) {
		super(name, type, numberOfWheels);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.fdmgroup.Vehicle#drive()
	 */
	@Override
	public void drive() {
	
		System.out.println("Driving a car");
	}

	/* (non-Javadoc)
	 * @see com.fdmgroup.Vehicle#brake()
	 */
	@Override
	public void brake() {
	
		System.out.println("braking! damn that was fast");
		
	}

	@Override
	public String toString() {
		return "Car [getName()=" + getName() + ", getType()=" + getType() + ", getNumberOfWheels()="
				+ getNumberOfWheels() + "]";
	}
	

}
