/**
 * 
 */
package com.fdmgroup;

/**
 * @author akrem.latiwesh
 *
 */
public class Suv extends Vehicle implements AllWheelDrivable {

	
	
	public Suv(String name, String type) {
		super(name, type);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.fdmgroup.AllWheelDrivable#jump()
	 */
	@Override
	public void jump() {
		System.out.println("SUV is jumping!");
		
	}

	/* (non-Javadoc)
	 * @see com.fdmgroup.Vehicle#drive()
	 */
	@Override
	public void drive() {
	System.out.println("SUV is driving!");
		
	}

	/* (non-Javadoc)
	 * @see com.fdmgroup.Vehicle#brake()
	 */
	@Override
	public void brake() {
		System.out.println("SUV is braking!");
		
	}

}
