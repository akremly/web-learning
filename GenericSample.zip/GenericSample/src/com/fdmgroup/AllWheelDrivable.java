/**
 * 
 */
package com.fdmgroup;

/**
 * @author akrem.latiwesh
 *
 */
public interface AllWheelDrivable {
	
	void jump();

}
