/**
 * 
 */
package com.fdmgroup;

/**
 * @author akrem.latiwesh
 *
 */

public abstract class Vehicle {

	private String name;
	private String type;
	private int numberOfWheels;
	
	
	public Vehicle(String name, String type) {
		super();
		this.name = name;
		this.type = type;
	}
	

	public Vehicle(String name, String type, int numberOfWheels) {
		super();
		this.name = name;
		this.type = type;
		this.numberOfWheels = numberOfWheels;
	}


	public Vehicle() {
		super();
	}

	

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public int getNumberOfWheels() {
		return numberOfWheels;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setNumberOfWheels(int numberOfWheels) {
		this.numberOfWheels = numberOfWheels;
	}
	
	@Override
	public String toString() {
		return "Vehicle [name=" + name + ", type=" + type + ", numberOfWheels=" + numberOfWheels + "]";
	}
	
	public abstract void drive();
	public abstract void brake();
	
}
