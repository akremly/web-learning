/**
 * 
 */
package com.fdmgroup;

/**
 * @author akrem.latiwesh
 *
 */
public class Arithmatic {

	/**
	 * @param i
	 * @param j
	 * @return
	 */
	public int sub(int i, int j) {
		// TODO Auto-generated method stub
		return i-j;
	}

	/**
	 * @param i
	 * @param j
	 * @return
	 */
	public int add(int i, int j) {
		
		return i+j;
	}

	/**
	 * @param i
	 * @param j
	 * @return
	 */
	public int mul(int i, int j) {
	
		return i*j;
	}

	/**
	 * @param i
	 * @param j
	 * @return
	 */
	public double div(int i, int j) {
		
		return i/j;
	}
	
public double div2(double i, double j) {
		if(j==0)
		 throw new ArithmeticException();
		else
		return i/j;
	}

}
