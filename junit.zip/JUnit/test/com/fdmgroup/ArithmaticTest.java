/**
 * 
 */
package com.fdmgroup;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author akrem.latiwesh
 *
 */
public class ArithmaticTest {
	public static Arithmatic arithmatic;
	
	@BeforeClass
	public static void setup(){
		arithmatic=new Arithmatic();
		System.out.println("Setting up!");
	}
	@Before
	public void beforeTest(){
	
		System.out.println("before each test");
	}
	
	@After
	public void afterTest(){
	
		System.out.println("afteer each test");
	}
	
	@AfterClass
	public static void teardown(){
		System.out.println("Tearing down!");
	}
	@Test
	public void testSub(){
		int actualValue= arithmatic.sub(10,5);
		assertEquals(actualValue,5);
	}
	
	@Test
	public void testAdd(){
		int actualValue= arithmatic.add(10,5);
		assertEquals(actualValue,15);
	}
	
	@Test
	public void testMul(){
		int actualValue= arithmatic.mul(10,5);
		assertEquals(actualValue,50);
	}
	
	@Test
	public void testDiv(){
		double actualValue= arithmatic.div(10,5);
		assertEquals(actualValue,2.0,0.01);
	}

}
