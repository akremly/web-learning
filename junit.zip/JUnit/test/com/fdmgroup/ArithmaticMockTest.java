/**
 * 
 */
package com.fdmgroup;

import static org.mockito.Mockito.*;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;
import  org.mockito.Mock;
import org.mockito.*;
import org.mockito.Spy;


/**
 * @author akrem.latiwesh
 *
 */
public class ArithmaticMockTest {
	
	@Mock 
	private static Arithmatic mockArithmatic;
	
	@Spy
	private static Arithmatic spyArithmatic;
	
	@BeforeClass
	public static void setup(){
		System.out.println("Inside setup");
		ArithmaticMockTest amt= new ArithmaticMockTest();
		MockitoAnnotations.initMocks(amt);
		
		
		when(mockArithmatic.add(15, 5)).thenReturn(20);
		when(mockArithmatic.add(20, 5)).thenReturn(25);
		
		when(mockArithmatic.sub(10, 5)).thenReturn(5);
		when(mockArithmatic.sub(20, 5)).thenReturn(15);
		
		when(mockArithmatic.mul(10, 5)).thenReturn(50);
		when(mockArithmatic.mul(20, 5)).thenReturn(100);
		
		when(mockArithmatic.div(10, 5)).thenReturn(2.0);
		when(mockArithmatic.div(20, 5)).thenReturn(4.0);
		
		when(mockArithmatic.div2(anyDouble(), eq(0.0))).thenThrow(ArithmeticException.class);
		
		when(spyArithmatic.add(15, 5)).thenReturn(20);
		when(spyArithmatic.add(20, 5)).thenReturn(25);
		
		when(spyArithmatic.sub(10, 5)).thenReturn(5);
		when(spyArithmatic.sub(20, 5)).thenReturn(15);
		
		when(spyArithmatic.mul(10, 5)).thenReturn(50);
		when(spyArithmatic.mul(20, 5)).thenReturn(100);
		
		when(spyArithmatic.div(10, 5)).thenReturn(2.0);
		when(spyArithmatic.div(20, 5)).thenReturn(4.0);
		
		
	
	}
	
	@Test
	public void testAdd(){
		assertEquals(20, mockArithmatic.add(15, 5));
		assertEquals(25, mockArithmatic.add(20, 5));
		assertEquals(0, mockArithmatic.add(30,5));
		assertEquals(35, spyArithmatic.add(30,5)); // the spy is a mock object but it does not find the value from the method in the mock. it will go to the real object
	}
	@Test(expected = ArithmeticException.class)
	public void testDiv2(){
		assertEquals(3.0, mockArithmatic.div2(20.0, 0.0),0.01);
	}
	

}
